import React, { useState } from "react";
import '../style/Profile.css';
import profileImage from '../assets/IMG_0575.JPG';
import {
  Avatar,
  Divider,
  ListItem,
  ListItemAvatar,
  List,
  ListItemText,Radio,TextField,Button
} from "@mui/material";
import Bar from "../components/Bar";

const Profile = () => {

  const proData = JSON.parse(localStorage?.getItem("loggedInUser"));

  const guestItem = JSON.parse(localStorage?.getItem(`${proData.email}`));
  const userEmail = proData.email;

  const[user, setUser] = useState({...guestItem});

  const handleChange = (e) => {
      const{name, value} = e.target;
      setUser({...user,[name]:value});
  }

  const handleSubmit = () => {
    console.log(user);
    localStorage.setItem(`${userEmail}`,JSON.stringify(user)); 
  }
  
  return (
    <div>
      <Bar />
      <div className="userDetail">
        <Avatar
          alt="Remy Sharp"
          src= {profileImage}
          sx={{ ml:2, mt: 3, width: 250, height: 250 }}
        />
        <List
          sx={{
            width: "100%",
            maxWidth: 360,
            bgcolor: "background.paper",
            mt: 5,
          }}
        >
          <ListItem>
            <ListItemText primary="Email" secondary={proData.email} />
          </ListItem>
          <Divider variant="inset" component="li" />
          <ListItem>
            <ListItemText primary="Name" secondary={guestItem.name} />
          </ListItem>
          <Divider variant="inset" component="li" />
          <ListItem>
            <ListItemText primary="Mode" secondary={guestItem.mode} />
          </ListItem>
          <Divider variant="inset" component="li" />
        </List>
      </div>
      <div className="editUser">
        <form className="editForm">
          <h1>Edit Profile</h1>
          <div>
            <TextField
              sx={{ width: 400, mb:4}}
              label="Name"
              type="text"
              name="name"
              value={user.name}
              onChange={(e) => handleChange(e)}
            />
          </div>
          <div>
            <TextField
              sx={{ width: 400 , mb: 4}}
              label="Password"
              type="password"
              name="password"
              value={user.password}
              onChange={(e) => handleChange(e)}
            />
          </div>

          <div>
            <TextField
              sx={{ width: 400 , mb:4}}
              label="Confirm Password"
              type="password"
              name="conPassword"
              value={user.conPassword}
              onChange={(e) => handleChange(e)}
            />
          </div>

          <div>
            <TextField
              sx={{ width: 400, mb:4 }}
              type="file"
              name="image"
              value={user.image}
              onChange={(e) => handleChange(e)}
            />
          </div>

          <Button
            sx={{ width: 400, mb: 4 }}
            variant="contained"
            onClick={handleSubmit}
          >
            Edit
          </Button>
          
        </form>
      </div>
    </div>
  );
};

export default Profile;
