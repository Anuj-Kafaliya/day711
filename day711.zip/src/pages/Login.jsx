import React from 'react'
import RightLogin from '../components/RightLogin'
const Login = () => {
  return (
    <div><RightLogin/></div>
  )
}

export default Login