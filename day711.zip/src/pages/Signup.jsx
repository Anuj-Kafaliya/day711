import React from 'react'
import RightSignup from '../components/RightSignup'

const Signup = () => {
  return (
    <div>
        <RightSignup />
    </div>
  )
}

export default Signup