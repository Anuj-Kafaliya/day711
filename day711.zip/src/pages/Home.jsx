import React from 'react'
import Cart from '../components/Cart'
import Bar from '../components/Bar'
import '../style/Home.css'
import AddItem from '../components/AddItem'
import ItemStore from '../components/ItemStore'
const Home = () => {
  return (
    <div>
      <Bar />
      <div className='Add'>
        <AddItem />
      </div>
      <div className='itemStore'>
        <ItemStore />
      </div>
      <div className='showCartItem'>

      </div>
    </div>
  );
}

export default Home