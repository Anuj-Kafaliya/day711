import React from 'react'
import { useState} from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, Button } from '@mui/material';
import '../style/RightLogin.css';
import loginImage from '../assets/loginImg.jpg'

const RightLogin = () => {

 const handleNavigate = () => {
    navigate('/signup')
 }
  const [user, setUser] = useState({
    email: "",
    password: "",
    mode:""
  });

  const [loginErrors, setLoginErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;

    setUser({ ...user, [name]: value });
  };

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const userObj = JSON.parse(localStorage.getItem(`${user.email}`));
    const errors = {};

    if (!user.email.trim()) {
      errors.email = "Email is required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(user.email)) {
      errors.email = "Email must follow general pattern";
    }

    if (!user.password) {
      errors.password = "Password is mandatory field";
    } else if (user?.password != userObj?.password) {
      errors.password = "Password is not correct";
    }

    setLoginErrors(errors);

    if (Object.keys(errors).length === 0) {
      const value = userObj.mode;
      user.mode = value;
      const userDetail = JSON.stringify(user);
      localStorage.setItem("loggedInUser", userDetail);
      navigate("/home");
      alert("You are logged in Successfully");
    }
  };

  return (
    <div>
      <div className="render">
        <div className='left'>
          <img className="loginImage" src={loginImage} />
        </div>
        <div className="main">
          <form className="loginForm" >
            <h1 style={{marginBottom : "40px"}}>Login</h1>
         
              <TextField sx={{width: 400}}
                type="email"
                name="email"
                value={user.email}
                placeholder="enter email"
                onChange={(e) => handleChange(e)}
              />
              
            {loginErrors.email && <span>{loginErrors.email}</span>}
        
              <TextField sx={{width: 400}}
                type="password"
                name="password"
                value={user.password}
                placeholder="enter password"
                onChange={(e) => handleChange(e)}
              />
             
            {loginErrors.password && <span>{loginErrors.password}</span>}
            <Button variant="contained" onClick={handleSubmit} sx={{width: 400, mt:4}}>
              Login
            </Button>
            <Button variant="contained" onClick={handleNavigate} sx={{mt:3, width:400}}>
              Want to create a new account??
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default RightLogin