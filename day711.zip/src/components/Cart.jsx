import React from "react";
import {
  Card,
  CardActionArea,
  CardMedia,
  Typography,
  Button,
  CardContent,
  CardActions,
} from "@mui/material";
import { useState } from 'react';

const Cart = (item) => {
  const user = JSON.parse(localStorage.getItem('loggedInUser'));
  console.log(user.mode);

  const [addedItem, setAddItem] = useState({
    name: "",
    desc: "",
    price: "",
    image: "https://cdn.pixabay.com/photo/2018/05/04/20/01/website-3374825_1280.jpg"
  });

  const handleAddToCart = (e) => {
    console.log(e.target.id);
  }
  return (
    <div>
      <Card sx={{ maxWidth: 345, ml: 10 }} >
        <CardActionArea>
          <CardMedia
            component="img"
            height="140"
            image="https://cdn.pixabay.com/photo/2018/05/04/20/01/website-3374825_1280.jpg"
            alt="green iguana"
          />
          <CardContent>
            <Typography gutterBottom variant="h5" component="div">
              {item.item.name}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {item.item.desc}
            </Typography>
            <Typography variant="body2" color="text.secondary">
              {item.item.price}
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
          {user.mode != 'admin' && (
            <Button size="small" color="primary" id={item.item.name} onClick={(e) => handleAddToCart(e)}>
              Add to cart
            </Button>
          )

          }
          {
            user.mode != 'Buyer' && (
              <Button size="small" color="primary">
                Delete
              </Button>
            )

          }
        </CardActions>
      </Card>
    </div>


  );
};

export default Cart;
