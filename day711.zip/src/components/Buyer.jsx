import React from 'react'

const Buyer = () => {
  return (
    <div>
      <div className='BuyerStore'>
        
      </div>

    </div>
  )
}

export default Buyer