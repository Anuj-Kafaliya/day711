import { TextField, Button } from '@mui/material'
import React from 'react'
import { useState } from 'react';
import '../style/AddForm.css'
import '../style/Home.css'


const AddItem = () => {

  const user = JSON.parse(localStorage.getItem('loggedInUser'));

  const [item, setItem] = useState({
    name: "",
    image: "",
    desc: "",
    price: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setItem({
      ...item,
      [name]: value
    })
  }

  let itemList = [];

  const handleSubmit = (e) => {
    e.preventDefault();
    const adminItem = JSON.parse(localStorage.getItem('items')) || [];
    localStorage.setItem('items', JSON.stringify([...adminItem, item]));
    itemList = JSON.parse(localStorage.getItem("items"));
    console.log(itemList)
    window.location.reload();
    //console.log([...adminItem,item]);
  }




  //const itemData = JSON.parse(localStorage.getItem('items'));
  //console.log(itemData)

  return (
    <div>
      {
        user.mode === 'admin' &&

        <div className='itemAdd'>
          <form className='addForm'>
            <center><h1>Add Items</h1></center>
            <TextField
              sx={{ width: 400 }}
              type="text"
              name="name"
              value={item.name}
              placeholder="enter item name"
              onChange={(e) => handleChange(e)}
            />
            <TextField
              sx={{ width: 400, mt: 3 }}
              type="text"
              name="image"
              value={item.image}
              placeholder="enter image url"
              onChange={(e) => handleChange(e)}
            />

            <TextField
              sx={{ width: 400, mt: 3 }}
              type="text"
              name="desc"
              value={item.desc}
              placeholder="enter item description"
              onChange={(e) => handleChange(e)}
            />

            <TextField
              sx={{ width: 400, mt: 3 }}
              type="text"
              name="price"
              value={item.price}
              placeholder="enter item price"
              onChange={(e) => handleChange(e)}
            />

            <Button variant="contained" onClick={handleSubmit} sx={{ width: 400, mt: 4, mb: 5 }}>
              ADD
            </Button>

          </form>
        </div>
      }


    </div>

  );
}

export default AddItem